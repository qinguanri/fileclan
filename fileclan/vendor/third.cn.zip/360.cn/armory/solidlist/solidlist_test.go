/*
Copyright 2013 Google Inc.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/

package solidlist

import (
	"math/rand"
	"testing"
)

func TestLPush(t *testing.T) {

	sl := New(87999)
	for i := 0; i < 1000; i++ {
		sl.RPush(ByteView{s: randStr(88)})
	}

	if sl.Len() != 999 {
		t.Error(`lpush  len 出错了，显示为： `)
	} else {
		t.Log(`lpush len 通过`)
	}
	if sl.Volume() != 87912 {
		t.Error(`lpush  volume 出错了 `)
	} else {
		t.Log(`lpush volume 通过`)
	}

}

func TestLPushPop(t *testing.T) {

	sl := New(0)
	for i := 0; i < 1000; i++ {
		sl.LPush(ByteView{s: randStr(66)})
	}
	for i := 0; i < 500; i++ {
		sl.RPop()
	}

	if sl.Len() != 500 {
		t.Error(`pushpop  len 出错了，显示为： `)
	}
	if sl.Volume() != 33000 {
		t.Error(`pushpop  volume 出错了 `)
	}

}

func randStr(n int) string {
	var letters = []rune("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ")
	b := make([]rune, n)
	for i := range b {
		b[i] = letters[rand.Intn(len(letters))]
	}
	return string(b)
}
