package poetry

import (
	"fmt"
	"testing"
)

func TestPlain(t *testing.T) {
	p := NewPlain()
	fmt.Println(p.Value())
	p.Update("sklar")
	fmt.Println(p.Value())
	p.Update("sklar2")
	fmt.Println(p.Value())
	if v := p.Value(); "sklar2" != v {
		t.Errorf("g.Value(): 47 != %v\n", v)
	}
}
