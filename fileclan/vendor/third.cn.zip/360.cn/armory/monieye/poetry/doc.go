// Package poetry provides various measuring instruments.
//
// This library is based on Coda Hale's original work:
// https://github.com/codahale/poetry, and a fork of
// https://github.com/rcrowley/go-poetry.
package poetry
