package poetry

import "sync"

// plains hold an int64 value that can be set arbitrarily.
type Plain interface {
	// Update the plain's value.
	Update(value string)

	// Return the plain's current value.
	Value() string
}

// The standard implementation of a plain uses the sync/atomic package
// to manage a single int64 value.
type plain struct {
	// just from Concurrent operation
	mutex sync.Mutex
	value string
}

// Create a new plain.
func NewPlain() Plain {
	return &plain{value: ""}
}

func (p *plain) Update(s string) {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	p.value = s
}

func (p *plain) Value() string {
	p.mutex.Lock()
	defer p.mutex.Unlock()
	return p.value
}
