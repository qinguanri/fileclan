package monieye

import (
	"encoding/json"
	// "fmt"
	"net/http"
	"path/filepath"
	"reflect"
	"strconv"
	"sync"

	"360.cn/armory/glog"
	"360.cn/armory/monieye/poetry"
	"github.com/gorilla/mux"
	"github.com/urfave/negroni"
)

// Monieye配置项
type Options struct {
	Switcher int
	Path     string
	Addr     string
}

// Monieye结构体
type Monieye struct {
	mutex   sync.RWMutex
	Metrics map[string]interface{}
	Path    string
	Addr    string
}

// 初始化Monieye
func InitMonieye(me *Monieye) {
	mux := mux.NewRouter()
	me.RegHandler(mux)

	n := negroni.Classic()
	selfDir, _ := filepath.Abs(me.Path)
	n.Use(negroni.NewStatic(http.Dir(selfDir)))
	n.UseHandler(mux)
	glog.V(5).Infoln(` Monieye strating... `)
	//start http server
	go func(serverAddr string) {
		n.Run(serverAddr)
	}(me.Addr)

}

func NewMonieye(option *Options) *Monieye {
	glog.V(5).Infoln(` New a Monieye... `)
	me := new(Monieye)
	me.Metrics = make(map[string]interface{})
	me.Path = option.Path
	me.Addr = option.Addr

	if option.Switcher == 1 {
		InitMonieye(me)
	}
	return me
}

// 注册Metrics
func (me *Monieye) RegMetric(name string, metric interface{}) interface{} {
	glog.V(5).Infoln(name, ` Regist metrics... `)
	me.mutex.Lock()
	defer me.mutex.Unlock()
	if _, ok := me.Metrics[name]; ok {
		//已经存在，命名冲突啦
		glog.V(5).Infoln(name, ` RegMetric error: name comflict... `)
	}
	me.Metrics[name] = metric
	return metric
}

// 注册路由
func (me *Monieye) RegHandler(mux *mux.Router) {
	mux.HandleFunc("/api/monieye/metrics/{action}", me.MetricsResponse)
}

// Metrics数据解析响应
func (me *Monieye) MetricsResponse(w http.ResponseWriter, req *http.Request) {
	vars := mux.Vars(req)
	metricName := vars["action"]
	glog.V(5).Infoln(metricName, ` action response... `)
	var res string
	switch value := me.Metrics[metricName]; vtype := me.Metrics[metricName].(type) {
	case poetry.Counter:
		res = metrics2json(reflect.TypeOf(value.(poetry.Counter)), reflect.ValueOf(value.(poetry.Counter)))
	case poetry.Gauge:
		res = metrics2json(reflect.TypeOf(value.(poetry.Gauge)), reflect.ValueOf(value.(poetry.Gauge)))
	case poetry.EWMA:
		res = metrics2json(reflect.TypeOf(value.(poetry.EWMA)), reflect.ValueOf(value.(poetry.EWMA)))
	case poetry.Plain:
		res = metrics2json(reflect.TypeOf(value.(poetry.Plain)), reflect.ValueOf(value.(poetry.Plain)))
	case poetry.Timer:
		res = metrics2json(reflect.TypeOf(value.(poetry.Timer)), reflect.ValueOf(value.(poetry.Timer)))
	case poetry.Sample:
		res = metrics2json(reflect.TypeOf(value.(poetry.Sample)), reflect.ValueOf(value.(poetry.Sample)))
	case poetry.Histogram:
		res = metrics2json(reflect.TypeOf(value.(poetry.Histogram)), reflect.ValueOf(value.(poetry.Histogram)))
	case poetry.Meter:
		res = metrics2json(reflect.TypeOf(value.(poetry.Meter)), reflect.ValueOf(value.(poetry.Meter)))
	case poetry.Flow:
		res = metrics2json(reflect.TypeOf(value.(poetry.Flow)), reflect.ValueOf(value.(poetry.Flow)))
	default:
		{
			strs, err := json.Marshal(struct {
				Error string `json:"error"`
			}{"Unknown"})
			if err != nil {
				glog.V(5).Infoln(err)
			}
			glog.V(5).Infoln(vtype)
			res = string(strs)
		}
	}

	w.Write([]byte(res))
}

// 反射用的一时爽，类型转换很是坑。
func metrics2json(t reflect.Type, v reflect.Value) string {
	data := make(map[string]interface{})
	for i := 0; i < t.NumMethod(); i++ {
		// 这里匹配那些没有参数并且有一个返回值的方法(对，你没有看错，没有参数的时候值就是1)
		if t.Method(i).Type.NumIn() == 1 && t.Method(i).Type.NumOut() == 1 {
			switch v.Method(i).Call([]reflect.Value{})[0].Interface().(type) {
			case int64:
				data[t.Method(i).Name] = strconv.FormatInt(v.Method(i).Call([]reflect.Value{})[0].Interface().(int64), 10)
			case string:
				data[t.Method(i).Name] = v.Method(i).Call([]reflect.Value{})[0].Interface().(string)
			case []float64:
				{
					var sli []string
					peres := v.Method(i).Call([]reflect.Value{})[0].Interface().([]float64)
					for index := 0; index < len(peres); index++ {
						sli = append(sli, strconv.FormatFloat(peres[index], 'G', 10, 64))
					}
					data[t.Method(i).Name] = sli
				}
			case []int64:
				{
					var sli []string
					peres := v.Method(i).Call([]reflect.Value{})[0].Interface().([]int64)
					for index := 0; index < len(peres); index++ {
						sli = append(sli, strconv.FormatInt(peres[index], 10))
					}
					data[t.Method(i).Name] = sli
				}
			case []([]byte):
				{
					var sli []string
					peres := v.Method(i).Call([]reflect.Value{})[0].Interface().([][]byte)
					for index := 0; index < len(peres); index++ {
						sli = append(sli, string(peres[index][0:len(peres[index])]))
					}
					data[t.Method(i).Name] = sli
				}
			case float64:
				data[t.Method(i).Name] = strconv.FormatFloat(v.Method(i).Call([]reflect.Value{})[0].Interface().(float64), 'G', 10, 64)
			}
		}
	}

	strs, err := json.Marshal(data)
	if err != nil {
		glog.V(5).Infoln(err)
	}
	return string(strs)
}
