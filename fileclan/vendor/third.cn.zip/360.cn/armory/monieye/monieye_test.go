package monieye

import (
	"flag"
	"fmt"
	"io/ioutil"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"testing"
	"time"

	"360.cn/armory/glog"
	"360.cn/armory/monieye/poetry"
)

var me Monieye

func TestMain(m *testing.M) {
	flag.Set("alsologtostderr", "true")
	flag.Set("log_dir", "/tmp")
	flag.Set("v", "3")
	flag.Parse()

	ret := m.Run()
	os.Exit(ret)
}

func httpGet(url string) {
	resp, err := http.Get(url)
	if err != nil {
		fmt.Println(err)
	}

	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		fmt.Println(err)
	}

	fmt.Println(string(body))
}

func TestMetricsResponse(t *testing.T) {
	me := NewMonieye(&Options{
		Path:     "/Users/wangguoliang/Documents/skylar_server_tools_code/gowork/dataforce/src/360.cn/cascade/static",
		Addr:     "127.0.0.1:9090",
		Switcher: 1,
	})

	me.RegMetric("flow", poetry.NewFlow(50))
	me.RegMetric("counter", poetry.NewCounter())
	me.RegMetric("gauge", poetry.NewGauge())
	me.RegMetric("plain", poetry.NewPlain())
	me.RegMetric("timer", poetry.NewTimer())
	me.RegMetric("sample", poetry.NewUniformSample(2))
	sam := poetry.NewUniformSample(20)
	me.RegMetric("histogram", poetry.NewHistogram(sam))
	me.RegMetric("meter", poetry.NewMeter())
	me.RegMetric("ewma", poetry.NewEWMA(float64(0.5)))

	me.Metrics["flow"].(poetry.Flow).RPush([]byte(time.Now().Format("2006-01-02 03:04:05 PM") + ` adding to venuscron... `))
	me.Metrics["flow"].(poetry.Flow).RPush([]byte(time.Now().Format("2006-01-02 03:04:05 PM") + ` fewghthrtyjn... `))
	me.Metrics["flow"].(poetry.Flow).RPush([]byte(time.Now().Format("2006-01-02 03:04:05 PM") + ` ahejruykil;o;lohrwweuwyh6ju.. `))

	me.Metrics["counter"].(poetry.Counter).Inc(34)
	me.Metrics["counter"].(poetry.Counter).Inc(5768)

	me.Metrics["gauge"].(poetry.Gauge).Update(45)
	me.Metrics["gauge"].(poetry.Gauge).Update(6)

	me.Metrics["sample"].(poetry.Sample).Update(45)
	me.Metrics["sample"].(poetry.Sample).Update(1334)

	me.Metrics["ewma"].(poetry.EWMA).Update(int64(45))
	me.Metrics["ewma"].(poetry.EWMA).Update(int64(3))

	me.Metrics["plain"].(poetry.Plain).Update("frguthj")
	me.Metrics["plain"].(poetry.Plain).Update("frguthj")

	me.Metrics["timer"].(poetry.Timer).Tick()
	me.Metrics["timer"].(poetry.Timer).UpdateSince(time.Date(2009, time.November, 10, 23, 0, 0, 0, time.UTC))
	me.Metrics["timer"].(poetry.Timer).Percentile()

	me.Metrics["histogram"].(poetry.Histogram).Percentile()
	me.Metrics["histogram"].(poetry.Histogram).Percentiles()

	me.Metrics["meter"].(poetry.Meter).Tick()

	urls := []string{
		"http://127.0.0.1:9090/api/monieye/metrics/flow",
		"http://127.0.0.1:9090/api/monieye/metrics/counter",
		"http://127.0.0.1:9090/api/monieye/metrics/gauge",
		"http://127.0.0.1:9090/api/monieye/metrics/plain",
		"http://127.0.0.1:9090/api/monieye/metrics/timer",
		"http://127.0.0.1:9090/api/monieye/metrics/histogram",
		"http://127.0.0.1:9090/api/monieye/metrics/meter",
		"http://127.0.0.1:9090/api/monieye/metrics/sample",
		"http://127.0.0.1:9090/api/monieye/metrics/ewma",
		"http://127.0.0.1:9090/api/monieye/metrics/error",
	}

	for _, url := range urls {
		go httpGet(url)
	}

	// 捕获ctrl-c,平滑退出
	chExit := make(chan os.Signal, 1)
	signal.Notify(chExit, syscall.SIGINT, syscall.SIGTERM, syscall.SIGKILL)
	select {
	case <-chExit:
		glog.Infoln("bye")
		glog.Flush()
	}
}
