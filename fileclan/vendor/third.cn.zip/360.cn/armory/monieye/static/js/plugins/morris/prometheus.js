// Morris.js Charts sample data for SB Admin template

$(function() {
    var flage = 0
    setTimeout(function() {
             Counters();
    },200);

    setInterval(function() {
        Counters();
    },2000);

    function Counters() {
        PushFlow("prometheus_event_log");
        PushFlow("prometheus_info_log");
        PushFlow("prometheus_warning_log");
        PushFlow("prometheus_error_log");
        PushCounter("prometheus_client_online");
        PushCounter("prometheus_broadcast_count");
        PushCounter("prometheus_relay_count");
        PushCounter("prometheus_sendmsg_count");
    }

    function PushCounter(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                datav = $.parseJSON(data).Count;
                $('#'+action).html(datav);
            }
        });
    }

    function PushFlow(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                datav = eval('('+data+')');
                if (action == "prometheus_info_log") {
                    TableWriter("#prometheus_info_log", data);
                    if (flage == 0) {
                        TableWriter("#prometheus_info_log", data);
                        flage = 1;
                    }
                }

                else if (action == "prometheus_warning_log") {
                    TableWriter("#prometheus_warning_log", data);
                    if (flage == 0) {
                        TableWriter("#prometheus_warning_log", data);
                        flage = 1;
                    }
                }

                else if (action == "prometheus_event_log") {
                    TableWriter("#prometheus_event_log", data);
                    if (flage == 0) {
                        TableWriter("#prometheus_event_log", data);
                        flage = 1;
                    }
                }

                else if (action == "prometheus_error_log") {
                    TableWriter("#prometheus_error_log", data);
                    if (flage == 0) {
                        TableWriter("#prometheus_error_log", data);
                        flage = 1;
                    }
                }
            }
        });
    }

    function TaskPanels(tasks){
        var str = "";
        var sum = tasks.length;
        if (sum > 10)  sum = 10;
        for (var i=0; i<sum; i++){
            str = str + '<a href="#" class="list-group-item">'+tasks[i]+' </a>';
        }
        $('#tasks-panel').html(str);
    }

    function TableWriter(id, data){
        if (data == null) {return}
        datav = $.parseJSON(data).Values;
        if (datav == null) {return}
        var str = ""
        for (var i=0; i<datav.length; i++){
            str = str + `<tr><td>`+ datav[i]+ `</td></tr>`;
        }
        $(id).html(str);
    }
});

