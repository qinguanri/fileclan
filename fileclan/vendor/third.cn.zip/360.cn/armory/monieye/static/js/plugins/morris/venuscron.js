// Morris.js Charts sample data for SB Admin template

$(function() {
    var flagt,flage = 0
    setTimeout(function() {
             Counters();
    },200);

    setInterval(function() {
        Counters();
    },2000);

    function Counters() {
        PushCounter("running_cron_jobs");
        PushCounter("have_completed_cron_jobs");
        PushCounter("failed_cron_jobs");
        PushCounter("totol_cron_jobs");
        PushFlow("event_action");
        PushFlow("error_event");
    }

    function PushCounter(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                datav = eval('('+data+')');
                $('#'+action).html(datav.Count);
            }
        });
    }

    function PushFlow(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                datav = eval('('+data+')');
                if (action == "event_action"){
                    TaskPanels(datav.Values);
                    if (flagt == 0) {
                        TaskAll(datav.Values);
                        flagt = 1;
                    }
                }
                else {
                    TaskErrorlog(datav.Values);
                    if (flage == 0) {
                        TaskErrorlogAll(datav.Values);
                        flage = 1;
                    }
                }
            }
        });
    }

    function TaskPanels(tasks){
        var str = "";
        var sum = tasks.length;
        if (sum > 10)  sum = 10;

        for (var i=0; i<sum; i++){
            str = str + '<a href="#" class="list-group-item">'+tasks[i]+' </a>';
        }
        $('#tasks-panel').html(str);
    }

    function TaskAll(tasks){
        var str = "";
        for (var i=0; i<tasks.length; i++){
            str = str + '<a href="#" class="list-group-item">'+tasks[i]+' </a>';
        }
        $('#tasks-panel').html(str);
    }

    function TaskErrorlog(errors){
        var str = "";
        var sum = errors.length
        if (sum > 10)  sum = 10
        for (var i=0; i<sum; i++){
            str = str + `<tr><td>`+ errors[i] + `</td></tr>`;
        }
        $('#error_log').html(str);
    }

    function TaskErrorlogAll(errors){
        var str = ""
        for (var i=0; i<errors.length; i++){
            str = str + `<tr><td>`+ errors[i]+ `</td></tr>`;
        }
        $('#error_log').html(str);
    }

});

