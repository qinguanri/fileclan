$(function() {
    var flagt,flage = 0
    setTimeout(function() {
             Counters();
    },200);

    setInterval(function() {
        Counters();
    },2000);

    function Counters() {
       PushPlain("prometheus_client_detail");
    }


    function PushPlain(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                datav = $.parseJSON(data).Value;
                if (action == "prometheus_client_detail"){
                    var content = JSON.parse(datav);
                    TaskPanels(content);
                    if (flagt == 0) {
                        TaskAll(content);
                        flagt = 1;
                    }
                }
            }
        });
    }

    function TaskPanels(tasks){
        var table = $("#tasks-panel");
        table.empty();
        var lines = [];

        $.each(tasks, function (index, item) {
            var line = $("<tr class='test'>");
            var tds = [];
            var td1 = $("<td>");

            td1.append(item.name);
            tds.push(td1);
            var td2 = $("<td>");

            td2.append(item.ip);
            tds.push(td2);
            var td3 = $("<td>");
            td3.append(item.ccid);
            tds.push(td3);
            line.append(tds);
            lines.push(line);
        });
        table.append(lines);
    }
});

