// Morris.js Charts sample data for SB Admin template

$(function() {
    var flage = 0
    setTimeout(function() {
             Counters();
    },200);

    setInterval(function() {
        Counters();
    },2000);

    function Counters() {
        PushFlow("loglineclient_info_log");
        PushFlow("prometheus_info_log");
        PushFlow("event_action");
    }

    function PushFlow(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                if (action == "prometheus_info_log") {
                    TableWriter("#prometheus_log", data);
                    if (flage == 0) {
                        TableWriter("#prometheus_log", data);
                        flage = 1;
                    }
                }

                else if (action == "event_action") {
                    TableWriter("#venuscron_log", data);
                    if (flage == 0) {
                        TableWriter("#venuscron_log", data);
                        flage = 1;
                    }
                }

                else if (action == "loglineclient_info_log") {
                    TableWriter("#logline_log", data);
                    if (flage == 0) {
                        TableWriter("#logline_log", data);
                        flage = 1;
                    }
                }
            }
        });
    }

    function TableWriter(id, data){
        if (data == null) {return}
        datav = $.parseJSON(data).Values;
        if (datav == null) {return}
        var str = ""
        for (var i=0; i<datav.length; i++){
            str = str + `<tr><td>`+ datav[i]+ `</td></tr>`;
        }
        $(id).html(str);
    }

});

