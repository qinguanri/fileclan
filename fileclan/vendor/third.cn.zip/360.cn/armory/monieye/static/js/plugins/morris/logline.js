$(function() {
    var flage = 0
    setTimeout(function() {
             Counters();
    },200);

    setInterval(function() {
        Counters();
    },2000);

    function Counters() {
        PushFlow("loglineclient_event_log");
        PushFlow("loglineclient_info_log");
        PushFlow("loglineclient_error_log");
        PushFlow("loglineserver_info_log");
        PushFlow("loglineserver_error_log");
        PushFlow("loglineserver_event_log");
        PushFlow("loglineserver_bstk_log");
    }

    function PushFlow(action){
        $.ajax({
            type:       "get",
            datatype:   "json",
            url:        "/api/monieye/metrics/"+action,
            success:    function(data){
                if (action == "loglineclient_error_log") {
                    TableWriter("#loglineclient_error_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineclient_error_log", data);
                        flage = 1;
                    }
                }

                else if (action == "loglineclient_info_log") {
                    TableWriter("#loglineclient_info_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineclient_info_log", data);
                        flage = 1;
                    }
                }

                else if (action == "loglineclient_event_log") {
                    TableWriter("#loglineclient_event_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineclient_event_log", data);
                        flage = 1;
                    }
                }

                else if (action == "loglineserver_info_log") {
                    TableWriter("#loglineserver_info_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineserver_info_log", data);
                        flage = 1;
                    }
                }
                 else if (action == "loglineserver_error_log") {
                    TableWriter("#loglineserver_error_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineserver_error_log", data);
                        flage = 1;
                    }
                }
                 else if (action == "loglineserver_event_log") {
                    TableWriter("#loglineserver_event_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineserver_event_log", data);
                        flage = 1;
                    }
                }
                 else if (action == "loglineserver_bstk_log") {
                    TableWriter("#loglineserver_bstk_log", data);
                    if (flage == 0) {
                        TableWriter("#loglineserver_bstk_log", data);
                        flage = 1;
                    }
                }
            }
        });
    }

    function TableWriter(id, data){
        if (data == null) {return}
        datav = $.parseJSON(data).Values;
        if (datav == null) {return}
        var str = ""
        for (var i=0; i<datav.length; i++){
            str = str + `<tr><td>`+ datav[i]+ `</td></tr>`;
        }
        $(id).html(str);
    }

});