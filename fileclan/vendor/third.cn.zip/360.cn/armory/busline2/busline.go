package busline2

// Busline2 支持Pg数据库select,delete,insert操作
import (
	"fmt"
	"reflect"
	"runtime"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/jmoiron/sqlx"

	"360.cn/armory/glog"
)

// 枚举列车模式
const (
	ModeSelect int = iota // 0:select操作模式
	ModeDelete            // 1:delete操作模式
	ModeInsert            // 2:insert操作模式
)

var (
	defaultBusConfig BusConfig
)

// 乘客标签，相当于车票类型是上铺(select),中铺(delete)还是下铺(insert)
type PsgrCategory struct {
	Mode  int
	Input interface{}
}

// 车辆配置，高，中，低配
type BusConfig struct {
	MaxInterval time.Duration
	BusNum      int
	BusCap      int
}

// 列车线
type BusLine struct {
	mu            *sync.RWMutex                    // 锁
	options       InitOptions                      // 配置项
	chanBusOnRoad chan int                         // 路上共有多少辆车
	psgrQueue     chan interface{}                 // 排队上车的乘客
	psgrRegister  map[string]chan chan interface{} // 每位上车的乘客，屁股后面都有一串订阅者
}

// 初始化busline对象所需初始条件
type InitOptions struct {
	Column      []string      // 需要操作数据库表的列名
	Pg          *sqlx.DB      // 数据库
	Tbl         string        // 表名
	PkColumn    []string      // 主键
	MaxInterval time.Duration // 前后两辆公交最长的发车间隔,单位为ns
	BusNum      int           // 一共有多少辆公交
	BusCap      int           // 每辆公交坐满能坐多少人
}

func init() {
	defaultBusConfig = configFromSystem()
}

// 新创建一个列车线
func NewBusLine(op InitOptions) *BusLine {
	b := &BusLine{options: op}
	b.mu = new(sync.RWMutex)
	// Busline的配置缺省或者出错则使用适配系统的默认设置
	if op.BusNum <= 0 || op.BusCap <= 0 || op.MaxInterval <= 0 {
		b.options.BusNum = defaultBusConfig.BusNum
		b.options.BusCap = defaultBusConfig.BusCap
		b.options.MaxInterval = defaultBusConfig.MaxInterval
	}
	// 排队等待上车的乘客排成的长长的队伍，这个chan是属于这条公交线的
	b.chanBusOnRoad = make(chan int, b.options.BusNum)
	b.psgrQueue = make(chan interface{}, b.options.BusNum*b.options.BusCap*10)
	b.psgrRegister = make(map[string]chan chan interface{})
	go b.dispatcher() // 车辆类型调度器启动
	return b
}

// OnBoard 是上车函数
func (b *BusLine) OnBoard(mode int, input interface{}) (waiter chan interface{}) {
	var subChain chan chan interface{}
	var ok bool
	b.mu.Lock()
	switch mode {
	case ModeSelect:
		key := strings.Join(input.([]string), `-`)

		if subChain, ok = b.psgrRegister[key]; !ok {
			subChain = make(chan chan interface{}, 10000)
			b.psgrRegister[key] = subChain
		}
	case ModeDelete:
		key := strings.Join(input.([]string), `-`)
		if subChain, ok = b.psgrRegister[key]; !ok {
			subChain = make(chan chan interface{}, 10000)
			b.psgrRegister[key] = subChain
		}
	case ModeInsert:
		v := reflect.ValueOf(input)
		key := fmt.Sprintf("%v", v)
		if subChain, ok = b.psgrRegister[key]; !ok {
			subChain = make(chan chan interface{}, 10000)
			b.psgrRegister[key] = subChain
		}
	default:
		glog.Errorf("Busline.OnBoard not support this Mode: %d", mode)
	}

	// 这个waiter相当于是一个中间载体目的是扔进去一个小车出来小车上就有货物了
	waiter = make(chan interface{})
	// 在此把小车扔进去然后一直等待着货物的装满，在broadcast()函数中装货物
	// chan 的操作不能当下锁里面，高并发情况会出现问题
	// 在找到解决上车和清车冲突方案之前，只能先放这啦
	subChain <- waiter
	b.mu.Unlock()

	b.psgrQueue <- PsgrCategory{mode, input}
	// 好了，货物已经取出来了，把小车推出去
	return waiter
}

//公交调度系统的核心功能模块
/*
乘客上车下车的过程为：
1：来一个查询请求，就塞入长长的排队等待上车的psgrQueue队列(A)中
2：开一个goroutine(B)，从busline的可用车辆队列chanBusOnRoad(C)中拿出一辆车(D),将A中的前几位乘客装入D中
3：D装满乘客或者D的发车时间到达就停止上客
4：将D中乘客拼成一条sql语句送到DB中查询得到rows总结果，此时此辆车重新放入可用车辆列表
5：第四步查询的结果rows逐条解析得到这个车里所有乘客的单条信息，逐个塞入chanResult这个返回channel中

每辆车对DB来说是一次查询，一次查询，一次查询
所以需要对每辆车内的所有乘客的查询做封装，拼接成一条sql语句，送到busXxxGo查询

*/
// dispatcher 发车调度，从排队的chan中在合适的时间内取出合适数量的乘客送上车，启动车辆运输
func (b *BusLine) dispatcher() {
	tick := time.Tick(b.options.MaxInterval)
	for {
		var selectBusPsgr = make([]interface{}, 0)
		var deleteBusPsgr = make([]interface{}, 0)
		var insertBusPsgr = make([]interface{}, 0)
		var wholeBusPsgr bool
	Exit:
		for i := 0; i < b.options.BusCap; i++ {
			select {
			case onePsgr := <-b.psgrQueue:
				wholeBusPsgr = true
				switch onePsgr.(PsgrCategory).Mode {
				case ModeSelect:
					selectBusPsgr = append(selectBusPsgr, onePsgr.(PsgrCategory).Input)
				case ModeDelete:
					deleteBusPsgr = append(deleteBusPsgr, onePsgr.(PsgrCategory).Input)
				case ModeInsert:
					insertBusPsgr = append(insertBusPsgr, onePsgr.(PsgrCategory).Input)
				default:
					glog.Errorf("Busline.dispatcher not support this Mode: %d", onePsgr.(PsgrCategory).Mode)
				}
			case <-tick: //时间到
				break Exit
			}
		}
		if wholeBusPsgr {
			if len(selectBusPsgr) > 0 {
				b.chanBusOnRoad <- 1            //取出一辆可用车辆
				go b.busSelectGo(selectBusPsgr) // select上路
			}
			if len(deleteBusPsgr) > 0 {
				b.chanBusOnRoad <- 1            //取出一辆可用车辆
				go b.busDeleteGo(deleteBusPsgr) // select上路
			}
			if len(insertBusPsgr) > 0 {
				b.chanBusOnRoad <- 1            //取出一辆可用车辆
				go b.busInsertGo(insertBusPsgr) // select上路
			}
		}
	}
}

// busGo 上路的bus，将车辆的乘客拼接成一条sql，到送入DB查询之前
func (b *BusLine) busSelectGo(wholeBusPsgr interface{}) {
	defer func() {
		<-b.chanBusOnRoad //往车库还一辆车
		// 筛一遍有没有没下车的，有的话轰下车
		for _, psgr := range wholeBusPsgr.([]interface{}) {
			b.broadcast(strings.Join(psgr.([]string), `-`), []byte("null"))
		}
	}()

	// 拼成(a,c) in ((:a0,:b0),(:a1,:b1),(:a2,:b2))这样的语句
	prepareMap := make(map[string]interface{}, 0)
	inStr := make([]string, 0) // 外面一层括号,如((1),(2),(3))最外面的那一层括号
	for busIndex, busValue := range wholeBusPsgr.([]interface{}) {
		inners := make([]string, 0) // 里面一层括号,如((1),(2),(3))里面的(1)和(2)和(3)
		preValues := busValue.([]string)
		for pkIndex := range b.options.PkColumn {
			preKeys := `pre_` + strconv.Itoa(pkIndex) + `_` + strconv.Itoa(busIndex) // 拼成pre_1_1这样的key的形式
			if pkIndex < len(preValues) {
				prepareMap[preKeys] = preValues[pkIndex]
			} else {
				glog.Errorln("null buffer pkvals")
				continue
			}
			inners = append(inners, `:`+preKeys)
		}
		inStr = append(inStr, `(`+strings.Join(inners, `,`)+`)`)

	}
	columns := strings.Join(b.options.Column, `,`)
	if columns == "" {
		columns = "*"
	}

	//sql语句
	sql := fmt.Sprintf(`SELECT CONCAT_WS('-', %s ) as idkeys,
                                        row_to_json(innerresult)#>>'{}' as rowjson
                                        FROM (SELECT %s FROM %s where (%s) in (%s)) innerresult ;`,
		strings.Join(b.options.PkColumn, `,`),
		columns,
		b.options.Tbl,
		strings.Join(b.options.PkColumn, `,`),
		strings.Join(inStr, `,`))

	rows, err := b.options.Pg.NamedQuery(sql, prepareMap)
	if err != nil {
		glog.Errorln(`Error occurs when Pg.NamedQuery`, err)
		return
	}
	defer rows.Close()

	// 下面逐个释放每个乘客
	for rows.Next() {
		var resp struct {
			IDKeys  string `db:"idkeys"`
			Rowjson []byte `db:"rowjson"`
		}
		if err := rows.StructScan(&resp); err != nil {
			// 有一个乘客死了，面目模糊，你不知道他是谁，有多少人在终点等着它，只能在defer里再点一遍名
			glog.Errorln(`when structed data record cause error:`, err.Error())
			continue
		}
		// ok，有结果啦就广播出去
		b.broadcast(resp.IDKeys, resp.Rowjson)
		// 赶下来这波乘客，该干嘛干嘛去吧
		wholeBusPsgr = arrayDelete(wholeBusPsgr.([]interface{}), resp.IDKeys)
		glog.V(5).Infoln(`one passenger come back result is:`, resp.Rowjson)
	}
}

// busDeleteGo 上路的bus，将要被“销毁”的乘客拼接成一条sql
func (b *BusLine) busDeleteGo(wholeBusPsgr interface{}) {
	defer func() {
		<-b.chanBusOnRoad //往车库还一辆车
		// 筛一遍有没有没下车的，有的话轰下车
		for _, psgr := range wholeBusPsgr.([]interface{}) {
			b.broadcast(strings.Join(psgr.([]string), `-`), []byte("null"))
		}
	}()

	//拼成(a,c) in ((:a0,:b0),(:a1,:b1),(:a2,:b2))这样的语句
	prepareMap := make(map[string]interface{}, 0)
	var inStr []string
	for busIndex, busValue := range wholeBusPsgr.([]interface{}) {
		var inners []string
		preValues := busValue.([]string)
		for pkIndex := range b.options.PkColumn {
			preKeys := `pre_` + strconv.Itoa(pkIndex) + `_` + strconv.Itoa(busIndex) //拼成pre_1_1这样的key的形式
			if pkIndex < len(preValues) {
				prepareMap[preKeys] = preValues[pkIndex]
			} else {
				glog.Errorln("null buffer pkvals")
				continue
			}
			inners = append(inners, `:`+preKeys)
		}
		inStr = append(inStr, `(`+strings.Join(inners, `,`)+`)`)
	}

	//sql语句
	sql := fmt.Sprintf(`DELETE FROM %s where (%s) in (%s) ;`,
		b.options.Tbl,
		strings.Join(b.options.PkColumn, `,`),
		strings.Join(inStr, `,`))

	res, err := b.options.Pg.NamedExec(sql, prepareMap)
	if err != nil {
		glog.Errorln(`Error occurs when Pg.NamedExec`, err)
	} else {
		affect, err := res.RowsAffected()
		if err != nil {
			glog.Errorln(`Error occurs when sql.Result.RowsAffected`, err)
		}
		for _, pkvals := range wholeBusPsgr.([]interface{}) {
			// ok，有结果啦就广播出去
			b.broadcast(strings.Join(pkvals.([]string), `-`), []byte(strconv.FormatInt(affect, 10)))
			// 赶下来这波乘客，该干嘛干嘛去吧
			wholeBusPsgr = arrayDelete(wholeBusPsgr.([]interface{}), strings.Join(pkvals.([]string), `-`))
		}
	}
}

// busInsertGo 上路的bus，将要被“销毁”的乘客拼接成一条sql
func (b *BusLine) busInsertGo(wholeBusPsgr interface{}) {
	defer func() {
		<-b.chanBusOnRoad // 往车库还一辆车
		// 筛一遍有没有没下车的，有的话轰下车
		for _, pkvals := range wholeBusPsgr.([]interface{}) {

			b.broadcast(fmt.Sprintf("%v", pkvals), []byte("null"))
		}
	}()
	iColumns := make([]string, 0)
	for _, cValue := range b.options.Column {
		iColumns = append(iColumns, `:`+cValue)
	}

	var colMultiPlaces []string
	args := make(map[string]interface{})
	for busIndex, busValues := range wholeBusPsgr.([]interface{}) {
		// var affects int64
		v := reflect.ValueOf(busValues)
		for i := 0; i < v.Len(); i++ {
			var colPlaces []string
			busValue := v.Index(i).Interface()
			t := reflect.TypeOf(busValue)
			valuesraw := fmt.Sprintf("%v", busValue)
			valuesra := strings.Replace(valuesraw, "{", "", -1)
			valuesr := strings.Replace(valuesra, "}", "", -1)
			values := strings.Split(valuesr, " ")
			for j := 0; j < t.NumField(); j++ {
				// key 作为数据库插入的标签$0_0,$0_1
				key := strconv.Itoa(busIndex) + "_" + strconv.Itoa(i) + "_" + strconv.Itoa(j)
				switch t.Field(j).Type.Kind() {
				case reflect.Int:
					in, err := strconv.Atoi(values[j])
					if err != nil {
						glog.Errorln(err)
					}
					args[key] = in
				case reflect.Float64:
					f, err := strconv.ParseFloat(values[j], 64)
					if err != nil {
						glog.Errorln(err)
					}
					args[key] = f
				case reflect.String:
					args[key] = values[j]
				}
				colPlaces = append(colPlaces, ":"+key)
			}
			colMultiPlaces = append(colMultiPlaces, strings.Join(colPlaces, ", "))
		}
	}
	// sql语句 很无奈的做法 这样觉得好不优雅 正确的应该是拿到外部结构体数组直接插入对应表
	// 鉴于目前修改太多，姑且先这样吧
	sql := fmt.Sprintf(`INSERT INTO %s (%s) VALUES (%v);`,
		b.options.Tbl,
		strings.Join(b.options.Column, `,`),
		strings.Join(colMultiPlaces, "),("))
	res, err := b.options.Pg.NamedExec(sql, args)
	if err != nil {
		glog.Errorln(`Error occurs when pg.NamedExec`, err)
	} else {
		affect, err := res.RowsAffected()
		if err != nil {
			glog.Errorln(`Error occurs when sql.Result.RowsAffected`, err)
		}
		for _, pkvals := range wholeBusPsgr.([]interface{}) {
			// ok，有结果啦就广播出去
			b.broadcast(fmt.Sprintf("%v", pkvals), []byte(strconv.FormatInt(affect, 10)))
			// 赶下来这波乘客，该干嘛干嘛去吧
			wholeBusPsgr = arrayStructDelete(wholeBusPsgr.([]interface{}), fmt.Sprintf("%v", pkvals))
		}
	}
}

// 广播出去乘客们是否安全抵达哦
func (b *BusLine) broadcast(psgr string, msg []byte) {
	b.mu.Lock()
	defer b.mu.Unlock()
	key := fmt.Sprintf("%s", psgr)
	if subChain, ok := b.psgrRegister[key]; ok {
		// 此处应该注意不能直接在循环里面使用len()，因为一旦close一个chan这个数字就变了，会导致严重bug
		leng := len(subChain)
	BROADCASTLOOP:
		for i := 0; i < leng; i++ {
			select {
			// 在此给小车装货
			case waiter := <-subChain:
				waiter <- msg
				close(waiter)
			default:
				break BROADCASTLOOP
			}
		}
		close(subChain)
	}
	delete(b.psgrRegister, key)
}

// 根据系统CPU数量设置默认工作方式
func configFromSystem() BusConfig {
	maxCPU := runtime.NumCPU()

	if maxCPU <= 4 {
		return BusConfig{
			MaxInterval: 10000000,
			BusNum:      20,
			BusCap:      50,
		}
	}

	if maxCPU <= 8 {
		return BusConfig{
			MaxInterval: 10000000,
			BusNum:      30,
			BusCap:      500,
		}
	}

	return BusConfig{
		MaxInterval: 100000000,
		BusNum:      50,
		BusCap:      1000,
	}
}

// 此处目的是赶下来已经有结果的乘客，采用曲线删除，增加就是减少，避免越界之类的隐患
func arrayDelete(wholeBusPsgr []interface{}, psg string) []interface{} {
	res := make([]interface{}, 0)
	for _, v := range wholeBusPsgr {
		if psg != strings.Join(v.([]string), "-") {
			res = append(res, v)
		}
	}
	return res
}

// 此处目的是赶下来Insert中的struct
func arrayStructDelete(wholeBusPsgr []interface{}, psg string) []interface{} {
	res := make([]interface{}, 0)
	for _, v := range wholeBusPsgr {
		if psg != fmt.Sprintf("%v", v) {
			res = append(res, v)
		}
	}
	return res
}
