/*
本lib就是从google家的GroupCache提取改装的

设计目标：
1、在内存中提供lru kv，有Set和Get,经常被Get的，往前排，不经常被Get的，慢慢向队伍末尾滑动。
2、可以控制最大容量(数量［个］或者容量［byte］)，超过后，队伍末尾开始丢东西
3、自带并发锁
4、存入的value是[]byte

e.g.

	slrukv := solidlrukv.New(1000000)

	slrukv.Add([]byte)
	slrukv.Get(string)
	slrukv.Volume()
	slrukv.Len()

大量用法请参考 solidlrukv_test.go

*/

package solidlrukv

import (
	///"bytes"
	"container/list"
	"errors"
	// "runtime"
	"sync"
)

type Cache struct {
	MaxBytes int64 //本instance所允许的最大byte数
	CntBytes int64 //当前已经使用的byte数
	//设置一个可以被调用者回调的函数，当因为内存不足而开始删除element时，可以让调用者收到事件
	OnEvicted func()
	IsFull    bool

	ll     *list.List
	roster map[interface{}]*list.Element //花名册

	mu sync.RWMutex //并发控制下
}

func New(maxBytes int64) *Cache {
	return &Cache{
		MaxBytes:  maxBytes,
		CntBytes:  0,
		ll:        list.New(),
		OnEvicted: func() {},
		IsFull:    false,
		roster:    make(map[interface{}]*list.Element),
	}
}

//从右边push
//此时如果容量满了，会从［左］边删除旧的元素
func (c *Cache) RPush(value []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.ll.PushFront(value)
	c.CntBytes += int64(len(value))
	if c.MaxBytes != 0 && c.CntBytes > c.MaxBytes {
		ele := c.ll.Back()
		c.CntBytes -= int64(len(ele.Value.([]byte)))
		c.ll.Remove(ele)
		if c.OnEvicted != nil {
			c.OnEvicted()
		}
	}
}

//从左边push
//此时如果容量满了，会从［右］边删除旧的元素
func (c *Cache) LPush(value []byte) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.ll.PushBack(value)
	c.CntBytes += int64(len(value))
	if c.MaxBytes != 0 && c.CntBytes > c.MaxBytes {
		ele := c.ll.Front()
		c.CntBytes -= int64(len(ele.Value.([]byte)))
		c.ll.Remove(ele)
		c.IsFull = true
		if c.OnEvicted != nil {
			c.OnEvicted()
		}
	} else {
		if c.IsFull {
			c.IsFull = false
		}
	}
}

//从左边pop
func (c *Cache) LPop() ([]byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	ele := c.ll.Back()
	if ele == nil {
		return []byte{}, errors.New("solidlist: null list")
	}
	c.ll.Remove(ele)
	c.CntBytes -= int64(len(ele.Value.([]byte)))
	if c.IsFull {
		c.IsFull = false
	}
	return ele.Value.([]byte), nil
}

//从右边pop
func (c *Cache) RPop() ([]byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	ele := c.ll.Front()
	if ele == nil {
		return []byte{}, errors.New("solidlist: null list")
	}
	c.ll.Remove(ele)
	c.CntBytes -= int64(len(ele.Value.([]byte)))
	if c.IsFull {
		c.IsFull = false
	}
	return ele.Value.([]byte), nil
}

//获取链表当前的容量，单位：byte
func (c *Cache) Volume() int64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return c.CntBytes
}

//获取链表元素数量，单位：个
func (c *Cache) Len() int64 {
	c.mu.Lock()
	defer c.mu.Unlock()
	return int64(c.ll.Len())
}
