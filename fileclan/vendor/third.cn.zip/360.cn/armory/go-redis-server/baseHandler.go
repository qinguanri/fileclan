package redis

type BaseHandler struct {
}

func (h *BaseHandler) Ping() (*StatusReply, error) {
	return &StatusReply{code: "PONG"}, nil
}

func (h *BaseHandler) Monitor() (*MonitorReply, error) {
	return &MonitorReply{}, nil
}
