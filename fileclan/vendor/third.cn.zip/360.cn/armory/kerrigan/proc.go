package kerrigan

import "runtime"

func (kr *Kerrigan) startProc2(procName string) (err error) {
	if runtime.GOOS == `windows` {
		return kr.startProcWindows(procName)
	} else {
		return kr.startProcPosix(procName)
	}
}

func (kr *Kerrigan) stopProc2(procName string) (err error) {
	if runtime.GOOS == `windows` {
		return kr.stopProcWindows(procName)
	} else {
		return kr.stopProcPosix(procName)
	}
}

func (kr *Kerrigan) startProcPosix(procName string) (err error) {
	return nil

}

func (kr *Kerrigan) stopProcPosix(procName string) (err error) {
	return nil
}

func (kr *Kerrigan) startProcWindows(procName string) (err error) {
	return nil
}

func (kr *Kerrigan) stopProcWindows(procName string) (err error) {
	return nil
}
