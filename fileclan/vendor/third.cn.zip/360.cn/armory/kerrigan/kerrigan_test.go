package kerrigan

import (
	"fmt"
	"sync"
	"testing"
	"time"
)

var kr *Kerrigan
var once sync.Once
var procTestHost = []struct {
	Name string
	Run  string
	Args []string
}{
	{"hostproc1", "./php", []string{`./test.php`}},
	{"hostproc2", "/Users/liuliu-s/Workspaces/skylar_server_tools_code/gowork/dataforce/src/360.cn/armory/kerrigan/php", []string{`./test.php`}},
	{"hostproc3", "/Users/liuliu-s/Workspaces/skylar_server_tools_code/gowork/dataforce/src/360.cn/armory/kerrigan/php", []string{`./test.php`}},
	//{"proc2", "ls", []string{`-lh`}},
	//{"proc3","c:\\windows",[]string{`-c`,`-b`}},
}

var procTestCron = []struct {
	Name string
	Run  string
	Args []string
}{
	{"cronproc1", "/Users/liuliu-s/Workspaces/skylar_server_tools_code/gowork/dataforce/src/360.cn/armory/kerrigan/php", []string{`./test.php`}},
	{"cronproc2", "/Users/liuliu-s/Workspaces/skylar_server_tools_code/gowork/dataforce/src/360.cn/armory/kerrigan/php", []string{`./test.php`}},
	{"cronproc3", "/Users/liuliu-s/Workspaces/skylar_server_tools_code/gowork/dataforce/src/360.cn/armory/kerrigan/php", []string{`./test.php`}},
	//{"proc2", "ls", []string{`-lh`}},
	//{"proc3","c:\\windows",[]string{`-c`,`-b`}},
}

func testSetup() {
	kr = NewKerrigan(InitOptions{HealthChkInterval: 10})
	//fmt.Printf("%# v \r\n", pretty.Formatter(skylar.SvrSystemSetting))
}

// func TestHost(t *testing.T) {
// 	once.Do(testSetup)
// 	fmt.Println(`Now Clearing...`)
// 	kr.Clear()
// 	for _, p := range procTest {
// 		fmt.Println(`Now AddToHost...`, p.Name)
// 		err := kr.AddToHost(3, p.Name, p.Run, p.Args)
// 		if err != nil {
// 			fmt.Println(err)
// 		}
// 	}
// 	fmt.Println(`test host done.`)
// 	select {}
// }

func TestCron(t *testing.T) {
	once.Do(testSetup)
	fmt.Println(`Now Clearing...`)
	kr.Clear()

	for _, p := range procTestHost {
		fmt.Println(`Now AddToHost...`, p.Name)
		err := kr.AddToHost(5, p.Name, p.Run, p.Args)
		if err != nil {
			fmt.Println(err)
		}
		time.Sleep(1 * time.Second)
	}

	for _, p := range procTestCron {
		fmt.Println(`Now AddToCron...`, p.Name)
		err := kr.AddToCron(`@every 10s`, p.Name, p.Run, p.Args)
		if err != nil {
			fmt.Println(err)
		}
		time.Sleep(1 * time.Second)
	}
	fmt.Println(`test cron done.`)
	time.Sleep(60 * time.Second)
	fmt.Println(`now cleaning`)
	kr.Clear()

	for _, p := range procTestHost {
		fmt.Println(`Now AddToHost...`, p.Name)
		err := kr.AddToHost(5, p.Name, p.Run, p.Args)
		if err != nil {
			fmt.Println(err)
		}
		time.Sleep(1 * time.Second)
	}

	for _, p := range procTestCron {
		fmt.Println(`Now AddToCron...`, p.Name)
		err := kr.AddToCron(`@every 10s`, p.Name, p.Run, p.Args)
		if err != nil {
			fmt.Println(err)
		}
		time.Sleep(1 * time.Second)
	}

	select {}
}

// func TestKill(t *testing.T) {
// 	once.Do(testSetup)
// 	for _, p := range procTest {
// 		fmt.Println(`Now AddToHost...`, p.Name)
// 		err := kr.AddToHost(2, p.Name, p.Run, p.Args)
// 		if err != nil {
// 			fmt.Println(err)
// 		}
// 	}
// 	fmt.Println(`now sleep 8s.`)
// 	time.Sleep(8 * time.Second)
// 	kr.Clear()
// 	fmt.Println(`test kill done.`)
// 	select {}
// }
