package kerrigan

import "os/exec"

// -- process information structure.
type procInfo struct {
	Name      string
	RetryLeft int //这个值表示进程退出后，还剩下多少次被kerrigan捞起来的机会，0表示不捞，-1表示永远都捞
	Run       string
	Args      []string
	Cmd       *exec.Cmd
}
