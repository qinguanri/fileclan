/*
	Kerrigan 进程之母
	拥有host自定义进程、cron自定义进程、runonce自定义进程的能力
	从github.com/mattn/goreman 抄来许多久经考验的代码：）
*/

package kerrigan

import (
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"sync"
	"time"

	"360.cn/armory/glog"
	"github.com/robfig/cron"
)

const DefaultHealthChkInterval = 10 //默认的进程健康检查间隔

func NewKerrigan(options InitOptions) *Kerrigan {
	kr := new(Kerrigan)
	kr.options = options
	kr.cronEngine = cron.New()
	kr.cronEngine.Start()
	kr.stage = make(map[string]*procInfo)
	if kr.options.HealthChkInterval <= 0 {
		kr.options.HealthChkInterval = DefaultHealthChkInterval
	}
	go kr.procCPR()
	return kr
}

type Kerrigan struct {
	sync.Mutex
	options    InitOptions
	stage      map[string]*procInfo //进程舞台，这里摆放所有进程
	muStage    sync.Mutex
	cronEngine *cron.Cron
}

type InitOptions struct {
	HealthChkInterval int
}

//添加一个需要host的进程
func (kr *Kerrigan) AddToHost(retry int, name string, run string, args []string) (err error) {
	//guard 一下
	if err = kr.guard(name, run, args); err != nil {
		return err
	}
	//摆放到stage上
	kr.stage[name] = &procInfo{Name: name, RetryLeft: retry, Run: run, Args: args, Cmd: nil}
	go kr.spawnProc(name)
	return nil
}

//添加一个cron进程
func (kr *Kerrigan) AddToCron(cron string, name string, run string, args []string) (err error) {
	kr.Lock()
	defer kr.Unlock()
	//guard 一下
	if err = kr.guard(name, run, args); err != nil {
		return err
	}
	//摆放到stage上
	kr.stage[name] = &procInfo{Name: name, RetryLeft: 0, Run: run, Args: args, Cmd: nil}
	func(cron string, name string) {
		_ = kr.cronEngine.AddFunc(cron, func() { kr.spawnProc(name) })
	}(cron, name)
	return nil
}

//清除kerrigan的所有托管进程、cron进程、once进程
func (kr *Kerrigan) Clear() {
	glog.V(2).Infoln(`now clearing`)
	kr.Lock()
	defer kr.Unlock()
	//停止cron滴答
	kr.cronEngine.Stop()
	kr.cronEngine = cron.New()
	kr.cronEngine.Start()
	//将所有正在运行的进程kill
	for name, p := range kr.stage {
		if p.Cmd != nil {
			kr.stopProc(name)
			glog.V(2).Infoln(`stop by clear:`, name)
		}
	}
	time.Sleep(2 * time.Second)
	for name, p := range kr.stage {
		if p.Cmd == nil {
			delete(kr.stage, name)
			glog.V(2).Infoln(`removed from stage:`, name)
		}
	}
}

//防御一下对AddToXXX们的调用，进程要真实可访问
func (kr *Kerrigan) guard(name string, run string, args []string) (err error) {
	//重名guard
	if _, ok := kr.stage[name]; ok {
		return errors.New(`kerrigan error: alreay has the proc name on stage: ` + name)
	}
	//路径有效性guard
	if _, err := os.Stat(run); err != nil {
		return errors.New(`kerrigan error: file notfound: ` + run)
	}
	return nil
}

//每隔一段时间，检查下进程们死了吗？要不要做人工呼吸救活？
func (kr *Kerrigan) procCPR() {
	for {
		time.Sleep(time.Duration(kr.options.HealthChkInterval) * time.Second)
		for k, v := range kr.stage {
			//fmt.Println(`CPR 1.`)
			if v.Cmd != nil || v.RetryLeft == 0 {
				continue
			}
			//fmt.Println(`CPR 2.`)
			if v.RetryLeft > 0 { //进程的重试次数－1
				v.RetryLeft -= 1
			}
			glog.Errorln(`now make CPR on proc`, k, v.RetryLeft)
			go kr.spawnProc(k) //如果RetryLeft＝－1，可以无限次的重启
		}
	}
}

func (kr *Kerrigan) spawnProc(name string) (err error) {
	//如果同名进程仍在运行，则默默退出
	if kr.stage[name].Cmd != nil {
		glog.Errorln(`spawnproc err: already running: `, name)
		return errors.New(`spawnproc err: already running: ` + name)
	}
	selfDir, err := filepath.Abs(filepath.Dir(os.Args[0]))
	exeFullPath := filepath.Join(selfDir, kr.stage[name].Run)
	kr.stage[name].Cmd = exec.Command(exeFullPath, kr.stage[name].Args...)
	kr.stage[name].Cmd.Env = os.Environ()
	kr.stage[name].Cmd.Dir = filepath.Dir(exeFullPath)
	glog.V(2).Infoln(fmt.Sprintf(`starting %s: run %s @ workdir %s`, name, exeFullPath, kr.stage[name].Cmd.Dir))
	if err = kr.stage[name].Cmd.Start(); err != nil {
		return err
	}
	kr.stage[name].Cmd.Wait()
	kr.stage[name].Cmd = nil
	glog.V(2).Infoln(name, ` stoped.`)
	return nil
}

func (kr *Kerrigan) stopProc(name string) (err error) {
	if p, ok := kr.stage[name]; ok {
		if p.Cmd != nil {
			glog.V(2).Infoln(`begin kill `, name)
			err = p.Cmd.Process.Kill()
			glog.V(2).Infoln(`done kill `, name)
		}
	}
	return err
}
