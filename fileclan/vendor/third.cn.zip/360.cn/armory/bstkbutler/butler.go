package bstkbutler

import (
	"errors"
	"strconv"
	"sync"
	"time"

	beanstalk "github.com/kr/beanstalk"
	"github.com/tcppool"
)

// InitOptions ...
type InitOptions struct {
	BstkConn             string
	BSTKPool_InitialCap  int           // 连接池中拥有的最小连接数
	BSTKPool_MaxCap      int           // 连接池中拥有的最大的连接数
	BSTKPool_IdleTimeout time.Duration // 链接最大空闲时间，超过该事件则将失效
	RestartBstkInterval  time.Duration // bstk任务轮重启频率
	ReserveTimeout       time.Duration // bstk任务轮reserve job time
	SingleTubeMaxJobNum  int           // bstk 单个
}

// JobInfo 👷工人数量
type JobInfo struct {
	Worker int
	Func   func([]byte) bool
}

// Butler ...
type Butler struct {
	factory             func() (interface{}, error)
	close               func(interface{}) error
	pool                tcppool.TCPPool
	BstkRouletteMap     map[string]*JobInfo //bstk的tube和对应消费函数的map
	mu                  sync.Mutex
	bstkConn            *beanstalk.Conn
	singleTubeMaxJobNum int
	done                sync.WaitGroup
	quit                chan struct{}
	RestartBstkInterval time.Duration
	ReserveTimeout      time.Duration
	sync.RWMutex
}

const SINGLETUBEMAXJOBNUMBER = 100000

// NewButler 初始化bstk管家
func NewButler(options InitOptions) *Butler {
	bt := new(Butler)
	// factory 创建连接的方法
	bt.factory = func() (interface{}, error) { return beanstalk.Dial(`tcp`, options.BstkConn) }
	// close 关闭链接的方法
	bt.close = func(c interface{}) error { return c.(*beanstalk.Conn).Close() }
	// 初始化一个beanstalk 连接池
	bt.pool, _ = tcppool.NewChannelPool(tcppool.InitOptions{
		InitialCap:  options.BSTKPool_InitialCap,
		MaxCap:      options.BSTKPool_MaxCap,
		Factory:     bt.factory,
		Close:       bt.close,
		IdleTimeout: options.BSTKPool_IdleTimeout, // 链接最大空闲时间，超过该时间的链接 将会关闭，可避免空闲时链接EOF，自动失效的问题
	})
	bt.quit = make(chan struct{})
	bt.singleTubeMaxJobNum = options.SingleTubeMaxJobNum
	if bt.singleTubeMaxJobNum <= 0 {
		bt.singleTubeMaxJobNum = SINGLETUBEMAXJOBNUMBER
	}
	// 初始化bstk轮子
	bt.BstkRouletteMap = make(map[string]*JobInfo)
	bt.RestartBstkInterval = options.RestartBstkInterval
	bt.ReserveTimeout = options.ReserveTimeout                     // bstk的tube和对应消费函数的map
	go bt.BstkRoulette2(bt.RestartBstkInterval, bt.ReserveTimeout) // 启动任务轮
	return bt
}

// PutJob put job to bstk
func (bt *Butler) PutJob(tube string, msg string) (err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return err
	}
	defer bt.pool.Put(bstkConn)
	if stats, err := bt.GetStatsForTube(tube); err == nil {
		count, _ := strconv.Atoi(stats.TotalJobs)
		if count > bt.singleTubeMaxJobNum {
			return errors.New(`SINGLE_TUBE_JOB_NUMBER_TOO_MUCH: singel tube job numbers exceeds max limit `)
		}
	}
	Tube := beanstalk.Tube{bstkConn.(*beanstalk.Conn), tube}
	_, err = Tube.Put([]byte(msg), 0, 0, 0)
	return err
}

//Bury bury job by id
func (bt *Butler) BuryJob(id uint64, pri uint32) (err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).Bury(id, pri)
}

//Bury bury job by id
func (bt *Butler) DeleteJob(id uint64) (err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).Delete(id)
}

//  KickJob kick job(可以指定条数)
func (bt *Butler) KickJob(tube string, bound int) (n int, err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return 0, err
	}
	defer bt.pool.Put(bstkConn)
	Tube := &beanstalk.Tube{bstkConn.(*beanstalk.Conn), tube}
	return Tube.Kick(bound)
}

// touch  job id
func (bt *Butler) Touch(id uint64) (err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).Touch(id)
}

// peek job id
func (bt *Butler) Peek(id uint64) (body []byte, err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return nil, err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).Peek(id)
}

// ReserveJobByTube reserve job by tube name
func (bt *Butler) ReserveJobByTube(tube string, timeout time.Duration) (id uint64, body []byte, err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return 0, nil, err
	}
	defer bt.pool.Put(bstkConn)
	bstkConn.(*beanstalk.Conn).TubeSet = *beanstalk.NewTubeSet(bstkConn.(*beanstalk.Conn), []string{tube}...)
	return bstkConn.(*beanstalk.Conn).Reserve(timeout)
}

// GetTubesName get tube list
func (bt *Butler) GetTubesName() (tubes []string, err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return nil, err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).ListTubes()
}

// DeleteJobByJobstats delete job By job stats
func (bt *Butler) DeleteJobByJobstats(tube, stats string) (err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return err
	}
	defer bt.pool.Put(bstkConn)
	var id uint64
	Tube := &beanstalk.Tube{bstkConn.(*beanstalk.Conn), tube}
	switch stats {
	case "buried":
		id, _, err = Tube.PeekBuried()
	case "ready":
		id, _, err = Tube.PeekReady()
	case "delayed":
		id, _, err = Tube.PeekDelayed()
	}
	if err != nil {
		return err
	}
	return bstkConn.(*beanstalk.Conn).Delete(id)
}

// 获取tube的状态
func (bt *Butler) GetStatsForTube(tube string) (*TubeStats, error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return nil, err
	}
	defer bt.pool.Put(bstkConn)
	Tube := &beanstalk.Tube{bstkConn.(*beanstalk.Conn), tube}
	stats, err := Tube.Stats()
	if err != nil {
		return nil, err
	}
	if name, ok := stats["name"]; !ok || name != tube {
		return nil, errors.New("Unable to retrieve tube stats")
	}
	return &TubeStats{
		JobsBuried:   stats["current-jobs-buried"],
		JobsReady:    stats["current-jobs-ready"],
		JobsDelayed:  stats["current-jobs-delayed"],
		JobsReserved: stats["current-jobs-reserved"],
		JobsUrgent:   stats["current-jobs-urgent"],
		Waiting:      stats["current-waiting"],
		TotalJobs:    stats["total-jobs"],
	}, nil
}

// get job stats by id
func (bt *Butler) GetStatsJobById(id uint64) (jobstat map[string]string, err error) {
	bstkConn, err := bt.pool.Get()
	if err != nil {
		return nil, err
	}
	defer bt.pool.Put(bstkConn)
	return bstkConn.(*beanstalk.Conn).StatsJob(id)
}
