package bstkbutler

import (
	"math"
	"math/rand"
	"strconv"
	"strings"
	"time"

	"360.cn/armory/glog"
	"github.com/kr/beanstalk"
)

// BstkRouletteTubeSet set tube names
func (bt *Butler) BstkRouletteTubeSet() {
	tubes := []string{}
	bt.RLock()
	for key, _ := range bt.BstkRouletteMap {
		tubes = append(tubes, key)
	}
	bt.RUnlock()
	if len(tubes) > 0 {
		bt.bstkConn.TubeSet = *beanstalk.NewTubeSet(bt.bstkConn, tubes...)
	}
}

// new 轮子
func (bt *Butler) BstkRoulette2(restart_bstk_intval, reserve_timeout time.Duration) {
	for name, jobInfo := range bt.BstkRouletteMap {
		select {
		case <-bt.quit:
			return
		default:
		}
		go func(name string, jobInfo *JobInfo) {
			defer bt.done.Done()
			var bstkConn *beanstalk.Conn
			bstkConn = bt.InitialBstk(restart_bstk_intval) // 每个任务注册都要开启bstkconn
			bstkConn.TubeSet = *beanstalk.NewTubeSet(bstkConn, name)
			var times int
			for {
				select {
				case <-bt.quit:
					return
				default:
				}
				// 判断这个流水线工人是否超标，预算不够s
				if times >= jobInfo.Worker {
					time.Sleep(restart_bstk_intval)
					continue
				}
				// reserve job
				id, msg, err := bstkConn.Reserve(reserve_timeout) //获取一个job
				if err != nil {
					if strings.Contains(err.Error(), "reserve-with-timeout: timeout") {
						time.Sleep(restart_bstk_intval)
						continue
					} else {
						glog.Errorln("Err in Reserve Job. ", err.Error())
						bstkConn = bt.InitialBstk(restart_bstk_intval) //重试到稳定
						continue
					}
				}
				// 获取job状态
				jobstat, err := bstkConn.StatsJob(id)
				if err != nil {
					glog.Errorln("Err in StatsJob Job. ", err.Error())
					bstkConn = bt.InitialBstk(restart_bstk_intval) //重试到稳定
					continue
				}
				pri, err := strconv.Atoi(jobstat["pri"])
				if err != nil {
					glog.Errorln("string to int. ", err.Error())
					continue
				}

				// bury job
				if err := bstkConn.Bury(id, uint32(pri)); err != nil {
					glog.Errorln("Bury Job err. ", err.Error())
					bstkConn = bt.InitialBstk(restart_bstk_intval) //重试到稳定
					continue
				}
				// execute out func and delete job
				consumer, ok := bt.BstkRouletteMap[jobstat["tube"]]
				if ok {
					bt.Lock()
					times++
					bt.Unlock()
					go func(msg []byte, id uint64, consumer *JobInfo) {
						if bool := consumer.Func(msg); bool {
							c_bstkConn := bt.InitialBstk(restart_bstk_intval)
							defer c_bstkConn.Close()
							if err := c_bstkConn.Delete(id); err != nil {
								glog.Errorln("Delete Job err. ", err.Error())
							}
						}
						bt.Lock()
						times = times - 1
						bt.Unlock()
					}(msg, id, consumer)
				}
			}
		}(name, jobInfo)
		bt.done.Add(1)
	}
}

// 获取job到指定方法中去执行
func (bt *Butler) BstkRoulette(restart_bstk_intval, reserve_timeout time.Duration) {
	bt.InitialBstk(restart_bstk_intval) //重试到稳定
	for {
		bt.BstkRouletteTubeSet()                             // set tube names
		id, msg, err := bt.bstkConn.Reserve(reserve_timeout) //获取一个job
		if err != nil {
			if strings.Contains(err.Error(), "reserve-with-timeout: timeout") {
				time.Sleep(restart_bstk_intval)
				continue
			} else {
				glog.Errorln("Err in Reserve Job. ", err.Error())
				bt.InitialBstk(restart_bstk_intval) //重试到稳定
				continue
			}
		}
		jobstat, err := bt.bstkConn.StatsJob(id)
		if err != nil {
			glog.Errorln("Err in StatsJob Job. ", err.Error())
			bt.InitialBstk(restart_bstk_intval) //重试到稳定
			continue
		}
		if err := bt.bstkConn.Delete(id); err != nil {
			glog.Warningln(`Err in delete job : `, err.Error())
			bt.InitialBstk(restart_bstk_intval) //重试到稳定
			continue
		}
		consumer, ok := bt.BstkRouletteMap[jobstat["tube"]]
		if ok {
			go consumer.Func(msg)
		}
	}
}

// BstkRouletteMapRegistry 外部函数注册 允许外部访问 //控制轮子
func (bt *Butler) BstkRouletteMapRegistry(registry map[string]*JobInfo) {
	bt.Lock()
	for key, value := range registry {
		bt.BstkRouletteMap[key] = value
	}
	close(bt.quit)
	bt.done.Wait()
	bt.quit = make(chan struct{})
	go bt.BstkRoulette2(bt.RestartBstkInterval, bt.ReserveTimeout) // 启动任务轮
	bt.Unlock()
}

// InitialBstk 初始化链接beanstalk
// 当bstk挂掉时重试，重试间隔可以逐步扩大到稳定
func (bt *Butler) InitialBstk(period time.Duration) (bstkconn *beanstalk.Conn) {
	bt.mu.Lock()
	stopCh := make(chan struct{})
	bt.JitterUntil(func() {
		if bstkConn, err := bt.factory(); err == nil {
			bstkconn = bstkConn.(*beanstalk.Conn)
			close(stopCh)
		}
	}, period, true, stopCh)
	glog.Infoln(`initial beanstalk successful.`)
	bt.mu.Unlock()
	return bstkconn
}

// 逐步扩大到稳定
func (bt *Butler) JitterUntil(f func(), period time.Duration, sliding bool, stopCh <-chan struct{}) {
	var t *time.Timer
	times := 1
	factor := 1
	for {
		select {
		case <-stopCh:
			return
		default:
		}
		jitteredPeriod := period
		jitteredPeriod, factor = bt.Jitter(period, times, factor)
		if !sliding {
			t = time.NewTimer(jitteredPeriod)
		}
		f()
		if sliding {
			t = time.NewTimer(jitteredPeriod)
		}
		select {
		case <-stopCh:
			return
		case <-t.C:
			times++
		}
	}
}

// 时间逐步增大到稳定
func (bt *Butler) Jitter(duration time.Duration, times int, factor int) (time.Duration, int) {
	switch {
	case times%2 == 0 && factor <= 30:
		factor++
		break
	case times%4 == 0 && factor <= 40:
		factor++
		break
	case times%10 == 0 && factor <= 50:
		factor++
		break
	case times%100 == 0:
		factor++
	}
	//fmt.Println(int(float64(factor)*math.Atan(float64(times)) + rand.Float64()))
	wait := duration + time.Duration(int(float64(factor)*math.Atan(float64(times))+rand.Float64()))*time.Second
	return wait, factor
}
