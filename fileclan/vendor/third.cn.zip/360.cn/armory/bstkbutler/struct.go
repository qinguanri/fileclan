package bstkbutler

type TubeStats struct {
	JobsBuried   string
	JobsDelayed  string
	JobsReady    string
	JobsReserved string
	JobsUrgent   string
	Waiting      string
	TotalJobs    string
}
