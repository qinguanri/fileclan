package utils

import (
	//"database/sql"
	"fmt"
	//_ "github.com/lib/pq"
	//"crypto/md5"
	//"encoding/hex"
	"errors"
	"reflect"
	"strings"
	"time"
)

func GetNowDateTime() string {
	time := []rune(time.Now().String())
	return string(time[0:19])
}

func ConsoleOut(msg ...string) {
	//go 的time format谁写的，这个变态。。。
	fmt.Print("[", time.Now().Format("2006-01-02 15:04:05"), "] ", strings.Join(msg, " "), "\n")
}

// func MergePlate(interface{}, interface{}) interface{} {

// }

// 判断obj是否在target中，target支持的类型arrary,slice,map
func Contain(obj interface{}, target interface{}) (bool, error) {
	targetValue := reflect.ValueOf(target)
	switch reflect.TypeOf(target).Kind() {
	case reflect.Slice, reflect.Array:
		for i := 0; i < targetValue.Len(); i++ {
			if targetValue.Index(i).Interface() == obj {
				return true, nil
			}
		}
	case reflect.Map:
		if targetValue.MapIndex(reflect.ValueOf(obj)).IsValid() {
			return true, nil
		}
	}

	return false, errors.New("not in array")
}
