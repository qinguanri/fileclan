package utils

import (
	"strconv"
	"time"
)

//日期类型
type Date struct {
	Year  int
	Month int
	Day   int
	Week  int
}

var (
	daycount = [12]int{31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
	weekday  = []rune("日一二三四五六")
)

//日期字符串方法
func (date *Date) String() string {
	y, m, d := strconv.Itoa(date.Year), strconv.Itoa(date.Month), strconv.Itoa(date.Day)
	if date.Month < 10 {
		m = "0" + m
	}
	if date.Day < 10 {
		d = "0" + d
	}
	s := y + "-" + m + "-" + d
	return s
}

//星期字符串方法
func (date *Date) WeekString() string {
	return "星期" + string(weekday[date.Week])
}

//前一天
func (date *Date) Prev() Date {
	var front Date
	if date.Day == 1 {
		if date.Month == 1 {
			front.Day = daycount[11]
			front.Month = 12
			front.Year = date.Year - 1
		} else {
			if date.Month == 3 {
				if LeapYear(date.Year) {
					front.Day = daycount[1] + 1
				} else {
					front.Day = daycount[1]
				}
				front.Month = 2
				front.Year = date.Year
			} else {
				front.Day = daycount[date.Month-2]
				front.Month = date.Month - 1
				front.Year = date.Year
			}
		}
	} else {
		front.Day = date.Day - 1
		front.Month = date.Month
		front.Year = date.Year
	}
	if date.Week == 0 {
		front.Week = 6
	} else {
		front.Week = date.Week - 1
	}
	return front
}

//获取当前日期
func DateNow() Date {
	dateN := Date{}
	now := time.Now()
	dateN.Year = now.Year()
	dateN.Month = int(now.Month())
	dateN.Day = now.Day()
	dateN.Week = int(now.Weekday())
	return dateN
}

//测试闰年
func LeapYear(year int) bool {
	if year%4 == 0 {
		return true
	}
	return false
}
