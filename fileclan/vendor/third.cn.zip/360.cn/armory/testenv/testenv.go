package testenv

import (
    "os"
    "errors"
    "encoding/json"
)

type TestEnv struct {
    Pgsql struct {
        Host string     `json:"host"`
        Port string     `json:"port"`
        User string     `json:"user"`
        Password string `json:"password"`
    } `json:"postgresql"`
    Redis struct {
        Host string      `json:"host"`
        Port string      `json:"port"`
        User string      `json:"user"`
        Password string  `json:"password"`
    } `json:"redis"`
    Bstk struct {
        Host string     `json:"host"`
        Port string     `json:"port"`
    } `json:"beanstalkd"`
    Es struct {
        Write string `json:"write"`
        ReadRawUrl string `json:"readRawUrl"`
    } `json:"es"`
    SkylarMinide struct {
        Host string `json:"host"`
        Port string `json:"port"`
    } `json:"skylarminide"`
}

func ReadTestEnv() (env *TestEnv, err error) {
    envstr := os.Getenv("SKYLAR6_GO_TEST_ENV")
    if len(envstr) < 1 {
        err = errors.New("Env SKYLAR6_GO_TEST_ENV not found")
        return
    }

    env = &TestEnv{}
    if err = json.Unmarshal([]byte(envstr), env); err != nil {
        return
    }

    return
}
