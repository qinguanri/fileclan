package schoolbell2

import (
	"fmt"
	"github.com/garyburd/redigo/redis"
	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"
	"testing"
	"time"
)

func TestSchoolBell2(t *testing.T) {
	psqlConnStr := fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=mini_box sslmode=disable", "daxiong.liuliu.net", "5432", "postgres", "Ilove360!")
	rdsConnStr := `daxiong.liuliu.net:6379`
	miniConnStr := `127.0.0.1:3801` //`10.18.31.60:3801`
	bstkConnStr := `daxiong.liuliu.net:11306`
	pg, err := sqlx.Open("postgres", psqlConnStr)
	if err != nil {
		t.Error(err)
	}
	pg.SetMaxIdleConns(10)
	pg.SetMaxOpenConns(100)
	rdsPool := newRdsPool(rdsConnStr, ``)
	miniPool := newMiniPool(miniConnStr)
	AddPg(pg)
	AddRedis(rdsPool)
	AddMinide(miniPool)
	AddBstk(bstkConnStr)
	Wait()
	fmt.Println(`all success`)

}

func newMiniPool(server string) *redis.Pool {
	return &redis.Pool{
		MaxIdle:     10,
		MaxActive:   5,
		IdleTimeout: 240 * time.Second,
		Dial: func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", server)
			if err != nil {
				return nil, err
			}
			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			_, err := c.Do("PING")
			return err
		},
	}
}

func newRdsPool(server, password string) *redis.Pool {
	return &redis.Pool{
		MaxIdle:     10,
		MaxActive:   5,
		IdleTimeout: 240 * time.Second,
		Dial: func() (redis.Conn, error) {
			c, err := redis.Dial("tcp", server)
			if err != nil {
				return nil, err
			}
			if password == "" {
				return c, err
			}
			if _, err := c.Do("AUTH", password); err != nil {
				c.Close()
				return nil, err
			}
			return c, err
		},
		TestOnBorrow: func(c redis.Conn, t time.Time) error {
			_, err := c.Do("PING")
			return err
		},
	}
}
