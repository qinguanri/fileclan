package schoolbell2

import (
	"360.cn/armory/glog"
	"github.com/garyburd/redigo/redis"
	"github.com/jmoiron/sqlx"
	"github.com/kr/beanstalk"
	_ "github.com/lib/pq"
	"sync"
	"time"
)

var (
	wg sync.WaitGroup
)

func Wait() {
	wg.Wait()
	glog.Infoln("postgresql,redis,bstk,minide ALL DONE.")
}

func AddPg(pg *sqlx.DB) {
	wg.Add(1)
	go linkPg(pg)
}

func AddBstk(bstkConnStr string) {
	wg.Add(1)
	go linkBstk(bstkConnStr)
}

func AddRedis(rds *redis.Pool) {
	wg.Add(1)
	go linkRedis(rds)
}

func AddMinide(miniPool *redis.Pool) {
	wg.Add(1)
	go linkMinide(miniPool)
}

func linkRedis(rds *redis.Pool) {
	var err error
	glog.Infoln("Now Waiting redis...")
	for {
		newRds := rds.Get()
		_, err = newRds.Do("PING")
		if err != nil {
			newRds.Close()
			glog.Infoln(err)
			time.Sleep(1 * time.Second / 2)
		} else {
			newRds.Close()
			break
		}
	}
	glog.Infoln("redis success")
	wg.Done()
}

func linkMinide(miniPool *redis.Pool) {
	var err error
	glog.Infoln("Now Waiting minide...")
	for {
		newMini := miniPool.Get()
		_, err = newMini.Do("PING")
		if err != nil {
			newMini.Close()
			glog.Infoln(err)
			time.Sleep(1 * time.Second / 2)
		} else {
			newMini.Close()
			break
		}
	}
	glog.Infoln("minide success")
	wg.Done()
}

func linkBstk(bstkConnStr string) {
	var err error
	glog.Infoln("Now Waiting bstk...")
	for {
		_, err = beanstalk.Dial("tcp", bstkConnStr)
		if err != nil {
			glog.Infoln(err)
			time.Sleep(1 * time.Second / 2)
		} else {
			break
		}
	}
	glog.Infoln("bstk success")
	wg.Done()
}

func linkPg(pg *sqlx.DB) {
	var err error
	glog.Infoln("Now Waiting postgresql...")
	for {
		err = pg.Ping()
		if err != nil {
			glog.Infoln(err)
			time.Sleep(1 * time.Second / 2)
		} else {
			break
		}
	}
	glog.Infoln("postgresql success")
	wg.Done()
}
