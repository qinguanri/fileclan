/*
 * clearLog
 *
 目标：
 设计一个package，可以被任何golang程序使用，一旦被main start，它会间隔性的扫描指定目录里的*.log文件，然后依据一些“清理规则”清理他们

 可以写死的清理规则：
 1、文件夹所有log文件加起来超过100MB了吗，如果超过，尝试从最早时间的日志文件开始删起，一直删到小于100MB
 2、删除10天前的所有log文件，顺序是尝试从最早时间的日志文件开始。
 3、删不掉就算了skip。
 *
*/

package logclear

import (
	"fmt"
	"io/ioutil"
	"os"
	"sort"
	"strings"
	"time"
)

const (
	SUM_SIZE_THRESHOLD = 104857600 // log总和(100MB)
	SECOND_TEN_DAY     = 864000    // 时间差常量
)

type LogClear struct {
	path      string
	timeinter int
}

type InitOption struct {
	Path      string
	TimeInter int
}
type LogInfo struct {
	logtime int64
	Path    string
	Size    int64
}
type LogInfos []LogInfo

func (u LogInfos) Len() int {
	return len(u)
}
func (u LogInfos) Less(i, j int) bool {
	return u[i].logtime < u[j].logtime
}
func (u LogInfos) Swap(i, j int) {
	u[i], u[j] = u[j], u[i]
}
func NewLogClear(option InitOption) *LogClear {
	lc := new(LogClear)
	lc.path = option.Path
	lc.timeinter = option.TimeInter
	go lc.clearLogRegular()
	return lc
}
func (lc *LogClear) clearLogRegular() {
	for {
		var sizeSum int64
		var location int = 0
		var log LogInfos

		//STEP1:搜集所有
		//获取指定目录下的log文件，同时记录每一个log文件的信息
		//存放在一个LogInfos型的切片中，记录是信息有（名称，大小和创建时间）
		files, err := ioutil.ReadDir(lc.path)
		if err != nil || len(files) == 0 {
			continue
		}
		for _, file := range files {
			ok := strings.HasSuffix(file.Name(), ".log")
			if ok {
				modTime := file.ModTime().Unix()
				size := file.Size()
				name := file.Name()
				var tmpPathSize LogInfo
				tmpPathSize.Path = string(string(os.PathSeparator) + name)
				tmpPathSize.Size = size
				tmpPathSize.logtime = modTime
				log = append(log, tmpPathSize)
				sizeSum = sizeSum + size
			}
		}
		//STEP2:排序&找出清理点
		//对切片按照创建时间进行排序，同时按照清理策略定位到需要清理的日志
		sort.Sort(log)
		nowtime := time.Now().Unix()
		for key, value := range log { // 定位
			timeDistance := nowtime - value.logtime
			if sizeSum > SUM_SIZE_THRESHOLD {
				sizeSum = sizeSum - value.Size
				location = key
				continue
			}
			if timeDistance > SECOND_TEN_DAY {
				location = key
				continue
			}
			if sizeSum <= SUM_SIZE_THRESHOLD && timeDistance <= SECOND_TEN_DAY {
				break
			}
		}
		//STEP3:清理
		//清理掉规则内的log文件
		for i := 0; i < location; i++ {
			err := os.Remove(lc.path + log[i].Path)
			if err != nil {
				fmt.Println(err)
			}
		}
		//定时执行日志清理，间隔由main指定
		time.Sleep(time.Duration(lc.timeinter) * time.Second)
	}
}
