/*
 * logclear_test
 * 测试logclear.go
 */
package logclear

import (
	"os"
	// "io/ioutil"
	"strconv"
	"testing"
	// "time"
	// "sync/once"
	"fmt"

	"360.cn/armory/glog"
)

// type ParamOption struct {
// 	path string
// 	timeinter time.Duration
// }
func TestLogClear(t *testing.T) {
	Option := InitOption{}
	Option.path = `/Users/taomin/skylar_server_tools_code/gowork/dataforce/src/360.cn/logfactory/logclear/log/`
	Option.timeinter = 3
	lc := NewLogClear(Option)
	fmt.Println(lc)
	go func() {
		for i := 0; i < 1000; i++ { // 生产
			name := strconv.Itoa(i) + ".log"
			path := `/Users/taomin/skylar_server_tools_code/gowork/dataforce/src/360.cn/logfactory/logclear/log/` + name
			fp, err := os.OpenFile(path, os.O_CREATE|os.O_RDWR, 0700)
			fmt.Printf("product %d\n", i)
			if err != nil {
				fp.Close()
				glog.V(5).Infoln(err)
				continue
			}
			_, err = fp.WriteAt([]byte{1}, 5000000)
			if err != nil {
				fp.Close()
				glog.V(5).Infoln(err)
				continue
			}
			fp.Close()
			fmt.Printf("product %d\n", i)
		}
	}()
	select {}
}
