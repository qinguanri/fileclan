package cpuid

//go:generate go run private-gen.go
